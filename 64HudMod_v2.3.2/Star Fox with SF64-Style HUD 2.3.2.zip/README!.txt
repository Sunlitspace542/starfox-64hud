-- Star Fox 64-Style HUD mod v2.3.2 by Sunlit --
Changes HUD to be closer to SF64’s layout, adds Star Fox 2 character mugshots (optional), adds the aiming reticle from third-person mode into first-person (optional), and upgrades the game to use FastROM and 21Mhz Super FX. (optional)

Patches apply to a Star Fox USA Rev 2 ROM file
The one to use is dependent on your preference.
If playing on real SNES, use one of the SlowROM options. (slowrom+21mhz or slowrom+10mhz)

2.3.2 Changes:

	ROMs with various configurations added:
	SlowROM/FastROM+10mhz/21mhz, reticle/no reticle, and sf1/sf2 mugshots

